from screen import Screen
import sys
from ship import Ship
from ship import MAX_TORPEDO_AMOUNT
import math
from asteroid import Astroid
import random
from torpedo import Torpedo
from torpedo import MAX_TORPEDO_AGE

DEFAULT_ASTEROIDS_NUM = 5
ROTATE_UP = 7
ROTATE_DOWN = -7
ACCELERATION_FACTOR = 2
ASTEROID_S3 = 30
ASTEROID_S2 = 50
ASTEROID_S1 = 100
class GameRunner:

    def __init__(self, asteroids_amnt=5):
        self._screen = Screen()
        self.__asteroids_amnt = asteroids_amnt
        self.screen_max_x = Screen.SCREEN_MAX_X
        self.screen_max_y = Screen.SCREEN_MAX_Y
        self.screen_min_x = Screen.SCREEN_MIN_X
        self.screen_min_y = Screen.SCREEN_MIN_Y
        self.__ship = Ship()
        self.__asteroids_list = []
        self.__torpedos_list = []
        self.__score = 0

    def run(self):
        self.place_astroids()
        self._do_loop()
        self._screen.start_screen()

    def _do_loop(self):
        # You don't need to change this method!
        self._game_loop()

        # Set the timer to go off again
        self._screen.update()
        self._screen.ontimer(self._do_loop,5)

    def x_movement(self, obj):
        """
        calculates the movement of ship on x axis according to the given
        formula
        :param ship: the item wanted moved
        :return: ship's new x coordinates according to it's speed and location
        """
        new_coord_x = (obj.get_x_vel() + obj.get_x_loc() - self.screen_min_x)\
                % (self.screen_max_x - self.screen_min_x) + self.screen_min_x
        obj.set_x_loc(new_coord_x)

    def y_movement(self, obj):
        """
        calculates the movement of ship on y axis according to the given
        formula
        :param ship: the item wanted moved
        :return: ship's new y coordinates according to it's speed and location
        """
        new_coord_y = (obj.get_y_vel() + obj.get_y_loc() - self.screen_min_y) \
                % (self.screen_max_y - self.screen_min_y) + self.screen_min_y
        obj.set_y_loc(new_coord_y)

    def accelerate(self):
        """this function is in charge of accelerating the ship"""
        if self._screen.is_up_pressed():
            self.accelerate_ship_x(),\
            self.accelerate_ship_y()

    def accelerate_ship_x(self):
        """this function is accelerating the ship on the x axis"""
        new_speed = self.__ship.get_x_vel() + math.cos(math.radians(
            self.__ship.get_orientation()))
        self.__ship.ship_accelerate_x(new_speed)

    def accelerate_ship_y(self):
        """this function is accelerating the ship on the x axis"""
        new_speed = self.__ship.get_y_vel() + math.sin(math.radians(
            self.__ship.get_orientation()))
        self.__ship.ship_accelerate_y(new_speed)

    def rotation(self):
        """this function deals with the rotation of the ship"""
        if self._screen.is_left_pressed():
            self.__ship.set_ship_orientation(ROTATE_UP)
        if self._screen.is_right_pressed():
            self.__ship.set_ship_orientation(ROTATE_DOWN)

    def all_movements_for_the_ship(self):
        """this function deals with all the movements of the ship"""
        self.rotation()
        self.accelerate()
        self.x_movement(self.__ship)
        self.y_movement(self.__ship)

    def place_astroids(self):
        """this function places asteroids on the screen"""
        for asteroid in range(self.__asteroids_amnt):
            curr_loc_x = random.randint(-500,500)
            curr_loc_y = random.randint(-500,500)
            while curr_loc_x == self.__ship.get_x_loc() and curr_loc_y == \
                    self.__ship.get_y_loc():
                curr_loc_x = random.randint(-500, 500)
                curr_loc_y = random.randint(-500, 500)
            curr_asteroid = Astroid(curr_loc_x,random.randint(0,10 )-5,
                    curr_loc_y,random.randint(0,10)-5)
            self.__asteroids_list.append(curr_asteroid)
            self._screen.register_asteroid(curr_asteroid,
                             curr_asteroid.get_size())

    def move_all_asteroids(self):
        for asteroid in self.__asteroids_list:
            self.x_movement(asteroid)
            self.y_movement(asteroid)

    def draw_asteroids(self):
        for asteroid in self.__asteroids_list:
            self._screen.draw_asteroid(asteroid,asteroid.get_x_loc(),
                                       asteroid.get_y_loc())

    def split_ast_speed_x(self,asteroid,torpedo):
        new_speed_x = (torpedo.get_x_vel()+asteroid.get_x_vel())/math.sqrt(
            pow(asteroid.get_x_vel(),2)+pow(asteroid.get_y_vel(),2))
        return new_speed_x

    def split_ast_speed_y(self,asteroid,torpedo):
        new_speed_y = (torpedo.get_y_vel()+asteroid.get_y_vel())/math.sqrt(
            pow(asteroid.get_x_vel(),2)+pow(asteroid.get_y_vel(),2))
        return new_speed_y

    def divide_asteroid(self,asteroid,torpedo):
        bool = 1
        new_x_speed = self.split_ast_speed_x(asteroid,torpedo)
        new_y_speed = self.split_ast_speed_y(asteroid,torpedo)
        while bool >= -1:
            new_asteroid = Astroid(asteroid.get_x_loc(),new_x_speed*bool,
                                   asteroid.get_y_loc(),new_y_speed*bool,
                                   asteroid.get_size()-1)
            self.__asteroids_list.append(new_asteroid)
            self._screen.register_asteroid(new_asteroid,new_asteroid.get_size())
            bool += -2

    def set_torp_x_vel(self):
        """
        this function calculates the speed of a torpedo on the x axis
        using the given formula.
        :return: the torpedo's speed on the x axis
        """
        rad_direct = math.radians(self.__ship.get_orientation())
        new_speed = self.__ship.get_x_vel() + 2 * math.cos(rad_direct)
        return new_speed

    def set_torp_y_vel(self):
        """
        this function calculates the speed of a torpedo on the y axis
        using the given formula.
        :return: the torpedo's speed on the y axis
        """
        rad_direction = math.radians(self.__ship.get_orientation())
        new_speed = self.__ship.get_y_vel() + 2 * math.sin(rad_direction)
        return new_speed

    def torpedo_counter(self):
        """
        this function helps enforce that there are no more than 15
        torpedoes in the game.
        """
        if len(self.__torpedos_list) < MAX_TORPEDO_AMOUNT:
            return True
        else:
            return False

    def lives_manager(self):
        """
        this function manages the life span of each torpedo, and making sure
        that there is no torpedo that is older the 200 iterations old
        """
        for index, torpedo in enumerate(self.__torpedos_list):
            torpedo.set_lives_counter()
            if torpedo.get_lives_counter() >= MAX_TORPEDO_AGE:
                self._screen.unregister_torpedo(torpedo)
                self.__torpedos_list.pop(index)

    def torpedo_managment(self):
        """
        this function manages the creation, deletion, drawing and defining
        all the games torpedoes.
        """
        self.lives_manager()
        if self._screen.is_space_pressed():
            cur_torpedo = Torpedo(self.set_torp_x_vel(), self.set_torp_y_vel(),
                                  self.__ship.get_x_loc(),
                                  self.__ship.get_y_loc(),
                                  self.__ship.get_orientation())
            self._screen.register_torpedo(cur_torpedo)
            self.__torpedos_list.append(cur_torpedo)
            self._screen.draw_torpedo(cur_torpedo, cur_torpedo.get_x_loc(),
                                      cur_torpedo.get_y_loc(),
                                      cur_torpedo.get_orientation())

    def draw_all_torpedos(self):
        """
        this function is managing all drawing of all torpedoes
        """
        for torpedo in self.__torpedos_list:
            self.x_movement(torpedo), self.y_movement(torpedo)
            self._screen.draw_torpedo(torpedo, torpedo.get_x_loc(),
                                      torpedo.get_y_loc(),
                                      torpedo.get_orientation())

    def all_movements(self):
        """this functions moves all the objects in the screen"""
        self.all_movements_for_the_ship()
        self.move_all_asteroids()

    def collision(self):
        """this function check if the any object has encountered the
        asteroids"""
        for index,asteroid in enumerate(self.__asteroids_list):
            if asteroid.has_intersection(self.__ship):
                if self.__ship.got_hit():
                    self.__asteroids_list.pop(index)
                    self._screen.show_message("You hit an asteroid!",
                        "remaining life is :"+str(self.__ship.get_life()))
                    self._screen.unregister_asteroid(asteroid)
                    self._screen.remove_life()
                else:
                    self._screen.show_message("YOU LOST!","You ran out of "
                                                          "lifes homie :(")
                    self._screen.end_game()
                    sys.exit()
            for index_t,torpedo in enumerate(self.__torpedos_list):
                if asteroid.has_intersection(torpedo):
                    if asteroid.get_size() == 1:
                        self.__torpedos_list.pop(index_t)
                        self._screen.unregister_torpedo(torpedo)
                        self.__asteroids_list.pop(index)
                        self._screen.unregister_asteroid(asteroid)
                        self.__score += ASTEROID_S1
                    else:
                        self.divide_asteroid(asteroid,torpedo)
                        self.__torpedos_list.pop(index_t)
                        self._screen.unregister_torpedo(torpedo)
                        self.__asteroids_list.pop(index)
                        self._screen.unregister_asteroid(asteroid)
                        if asteroid.get_size == 2:
                            self.__score += ASTEROID_S2
                        else:
                            self.__score += ASTEROID_S3
                self._screen.set_score(self.__score)

    def draw_all(self):
        """this function draws all the objects on the board"""
        self._screen.draw_ship(self.__ship.get_x_loc(), self.__ship.get_y_loc()
                               , self.__ship.get_orientation())
        self.draw_asteroids()
        self.draw_all_torpedos()

    def game_ending_manager(self):
        """
        this function manages every case in which the game should end,
        and printing an informative question about the reason the game has
        ended.
        """
        if self._screen.should_end():
            self._screen.show_message("Game aborted!",'The button q was '
                                        'pressed,and thus game has ended')
            self._screen.end_game()
            sys.exit()
        elif self.__asteroids_list == []:
            self._screen.show_message("Victory!",'you won you homie! '
                                                 'congrats! Your score '
                                                 'is : '+str(self.__score))
            self._screen.end_game()
            sys.exit()

    def _game_loop(self):
        self.game_ending_manager()
        self.collision()
        self.all_movements()
        self.draw_all()
        self.torpedo_managment()


def main(amnt):
    runner = GameRunner(amnt)
    runner.run()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        main( int( sys.argv[1] ) )
    else:
        main( DEFAULT_ASTEROIDS_NUM )